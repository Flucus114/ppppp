package com.devourervoid.client;

import com.devourervoid.DevourerMod;
import com.devourervoid.entity.VoidCrystalEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class VoidCrystalModel extends GeoModel<VoidCrystalEntity> {

    @Override
    public ResourceLocation getModelResource(VoidCrystalEntity entity) {
        return new ResourceLocation(DevourerMod.MOD_ID, "geo/void_crystal.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(VoidCrystalEntity entity) {
        return new ResourceLocation(DevourerMod.MOD_ID, "textures/entity/void_crystal.png");
    }

    @Override
    public ResourceLocation getAnimationResource(VoidCrystalEntity entity) {
        return new ResourceLocation(DevourerMod.MOD_ID, "animations/void_crystal.animation.json");
    }
}
