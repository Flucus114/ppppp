package com.devourervoid.client;

import com.devourervoid.DevourerMod;
import com.devourervoid.entity.VoidCrystalEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class VoidCrystalRenderer extends GeoEntityRenderer<VoidCrystalEntity> {

    public VoidCrystalRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new VoidCrystalModel());
        this.shadowRadius = 0.2f;
    }

    @Override
    public ResourceLocation getTextureLocation(VoidCrystalEntity entity) {
        return new ResourceLocation(DevourerMod.MOD_ID, "textures/entity/void_crystal.png");
    }
}
