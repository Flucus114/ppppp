package com.devourervoid.client;

import com.devourervoid.DevourerMod;
import com.devourervoid.entity.DevourerEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class DevourerModel extends GeoModel<DevourerEntity> {

    @Override
    public ResourceLocation getModelResource(DevourerEntity entity) {
        return new ResourceLocation(DevourerMod.MOD_ID, "geo/devourer_of_the_void.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(DevourerEntity entity) {
        return new ResourceLocation(DevourerMod.MOD_ID, "textures/entity/devourer_of_the_void.png");
    }

    @Override
    public ResourceLocation getAnimationResource(DevourerEntity entity) {
        return new ResourceLocation(DevourerMod.MOD_ID, "animations/devourer_of_the_void.animation.json");
    }
}
