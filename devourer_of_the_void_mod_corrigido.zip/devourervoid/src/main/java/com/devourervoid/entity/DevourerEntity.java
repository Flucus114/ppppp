package com.devourervoid.entity;

import com.devourervoid.entity.ai.*;
import com.devourervoid.init.ModParticles;
import com.devourervoid.init.ModSounds;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.*;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.*;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.*;
import software.bernie.geckolib.util.GeckoLibUtil;

public class DevourerEntity extends Monster implements GeoEntity {

    // DataParameters - definidos como publicos para acesso nos Goals
    public static final EntityDataAccessor<Integer> PHASE =
        SynchedEntityData.defineId(DevourerEntity.class, EntityDataSerializers.INT);
    public static final EntityDataAccessor<Boolean> IS_CHARGING =
        SynchedEntityData.defineId(DevourerEntity.class, EntityDataSerializers.BOOLEAN);
    public static final EntityDataAccessor<Boolean> IS_ROARING =
        SynchedEntityData.defineId(DevourerEntity.class, EntityDataSerializers.BOOLEAN);

    // GeckoLib
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    private static final RawAnimation IDLE     = RawAnimation.begin().thenLoop("animation.devourer.idle");
    private static final RawAnimation WALK     = RawAnimation.begin().thenLoop("animation.devourer.walk");
    private static final RawAnimation RUN      = RawAnimation.begin().thenLoop("animation.devourer.run");
    private static final RawAnimation ROAR     = RawAnimation.begin().thenPlay("animation.devourer.roar");
    private static final RawAnimation VOID_RAY = RawAnimation.begin().thenPlay("animation.devourer.void_ray");

    // Estado
    private int attackCooldown = 0;
    private int phaseLockTimer = 0;
    private boolean phaseP2 = false;
    private boolean phaseP3 = false;

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
            .add(Attributes.MAX_HEALTH,          1200.0)
            .add(Attributes.MOVEMENT_SPEED,        0.22)
            .add(Attributes.ATTACK_DAMAGE,          18.0)
            .add(Attributes.ARMOR,                  20.0)
            .add(Attributes.ARMOR_TOUGHNESS,        10.0)
            .add(Attributes.KNOCKBACK_RESISTANCE,    1.0)
            .add(Attributes.FOLLOW_RANGE,           64.0);
    }

    public DevourerEntity(EntityType<? extends Monster> type, Level level) {
        super(type, level);
        this.xpReward = 500;
        this.setPersistenceRequired();
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(PHASE,       1);
        entityData.define(IS_CHARGING, false);
        entityData.define(IS_ROARING,  false);
    }

    public int  getPhase()       { return entityData.get(PHASE); }
    public boolean isCharging()  { return entityData.get(IS_CHARGING); }
    public boolean isRoaring()   { return entityData.get(IS_ROARING); }
    public void setCharging(boolean v) { entityData.set(IS_CHARGING, v); }
    public void setRoaring(boolean v)  { entityData.set(IS_ROARING, v); }
    private void setPhase(int p)       { entityData.set(PHASE, p); }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new DevourerSmashGoal(this));
        goalSelector.addGoal(2, new DevourerVoidRayGoal(this));
        goalSelector.addGoal(3, new DevourerCrystalGoal(this));
        goalSelector.addGoal(4, new DevourerRoarGoal(this));
        goalSelector.addGoal(5, new MeleeAttackGoal(this, 1.0, true));
        goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 0.8));
        goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 32.0f));
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide) {
            if (attackCooldown > 0) attackCooldown--;
            if (phaseLockTimer  > 0) phaseLockTimer--;
            checkPhaseTransition();
        }
        spawnAmbientParticles();

        Player nearest = level().getNearestPlayer(this, 32.0);
        if (nearest != null) getLookControl().setLookAt(nearest, 30f, 30f);
    }

    private void checkPhaseTransition() {
        double ratio = getHealth() / getMaxHealth();
        if (getPhase() == 1 && ratio <= 0.66 && !phaseP2) triggerPhaseShift(2);
        else if (getPhase() == 2 && ratio <= 0.33 && !phaseP3) triggerPhaseShift(3);
    }

    private void triggerPhaseShift(int newPhase) {
        if (newPhase == 2) phaseP2 = true;
        if (newPhase == 3) phaseP3 = true;
        setPhase(newPhase);
        phaseLockTimer = 80;
        playSound(ModSounds.DEVOURER_PHASE_SHIFT.get(), 4.0f, newPhase == 3 ? 0.6f : 0.8f);
        getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(newPhase == 2 ? 0.27 : 0.32);

        if (!level().isClientSide && level() instanceof ServerLevel sl) {
            for (int i = 0; i < 60; i++) {
                sl.sendParticles(ModParticles.COSMIC_ENERGY.get(),
                    getX() + (random.nextDouble()-0.5)*4,
                    getY() + random.nextDouble()*5.5,
                    getZ() + (random.nextDouble()-0.5)*4,
                    1, 0, 0.1, 0, 0.05);
            }
        }
    }

    private void spawnAmbientParticles() {
        if (level().isClientSide && tickCount % 4 == 0) {
            int count = getPhase() == 1 ? 1 : getPhase() == 2 ? 2 : 4;
            for (int i = 0; i < count; i++) {
                level().addParticle(ModParticles.COSMIC_ENERGY.get(),
                    getX() + (random.nextDouble()-0.5)*2.5,
                    getY() + random.nextDouble()*5.0,
                    getZ() + (random.nextDouble()-0.5)*2.5,
                    0, 0.03, 0);
            }
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Phase", getPhase());
        tag.putBoolean("PhaseP2", phaseP2);
        tag.putBoolean("PhaseP3", phaseP3);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setPhase(tag.getInt("Phase"));
        phaseP2 = tag.getBoolean("PhaseP2");
        phaseP3 = tag.getBoolean("PhaseP3");
    }

    @Override protected SoundEvent getAmbientSound()            { return ModSounds.DEVOURER_AMBIENT.get(); }
    @Override protected SoundEvent getHurtSound(DamageSource d) { return ModSounds.DEVOURER_ROAR.get(); }
    @Override protected SoundEvent getDeathSound()              { return ModSounds.DEVOURER_DEATH.get(); }
    @Override protected void playStepSound(net.minecraft.core.BlockPos pos, net.minecraft.world.level.block.state.BlockState state) {
        playSound(ModSounds.DEVOURER_STEP.get(), 1.5f, 0.8f);
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (!level().isClientSide && level() instanceof ServerLevel sl) {
            for (int i = 0; i < 100; i++) {
                sl.sendParticles(ModParticles.COSMIC_ENERGY.get(),
                    getX()+(random.nextDouble()-0.5)*6,
                    getY()+random.nextDouble()*6,
                    getZ()+(random.nextDouble()-0.5)*6,
                    1, 0, 0.2, 0, 0.1);
            }
        }
    }

    // GeckoLib
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar r) {
        r.add(new AnimationController<>(this, "main", 5, state -> {
            if (isRoaring())  return state.setAndContinue(ROAR);
            if (isCharging()) return state.setAndContinue(VOID_RAY);
            if (state.isMoving()) {
                return state.setAndContinue(
                    getDeltaMovement().horizontalDistanceSqr() > 0.06 ? RUN : WALK);
            }
            return state.setAndContinue(IDLE);
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }

    @Override
    public boolean removeWhenFarAway(double distanceToClosestPlayer) { return false; }

    public boolean canAttack()         { return attackCooldown <= 0 && phaseLockTimer <= 0; }
    public void    setCooldown(int t)  { attackCooldown = t; }
}
