package com.devourervoid.entity.ai;

import com.devourervoid.entity.DevourerEntity;
import com.devourervoid.init.ModParticles;
import com.devourervoid.init.ModSounds;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

public class DevourerVoidRayGoal extends Goal {

    private final DevourerEntity boss;
    private int tick = 0;
    private static final int CHARGE_TIME = 50;
    private static final int COOLDOWN    = 200;

    public DevourerVoidRayGoal(DevourerEntity boss) {
        this.boss = boss;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (boss.getPhase() < 2) return false;
        LivingEntity t = boss.getTarget();
        return t != null && boss.canAttack() && boss.distanceToSqr(t) > 36.0
            && boss.getRandom().nextInt(20) == 0;
    }

    @Override
    public void start() {
        tick = 0;
        boss.setCharging(true);
        boss.playSound(ModSounds.DEVOURER_CORE_CHARGE.get(), 3.0f, 0.8f);
    }

    @Override
    public boolean canContinueToUse() { return tick < CHARGE_TIME + 20; }

    @Override
    public void tick() {
        tick++;
        if (boss.level() instanceof ServerLevel sl && tick < CHARGE_TIME && tick % 3 == 0) {
            Vec3 core = boss.position().add(0, 2.5, 0);
            for (int i = 0; i < 4; i++) {
                sl.sendParticles(ModParticles.COSMIC_ENERGY.get(),
                    core.x, core.y, core.z, 1,
                    (boss.getRandom().nextDouble()-0.5)*0.3, 0,
                    (boss.getRandom().nextDouble()-0.5)*0.3, 0.05);
            }
        }
        if (tick == CHARGE_TIME) fireRay();
    }

    private void fireRay() {
        LivingEntity target = boss.getTarget();
        if (target == null) return;
        boss.playSound(ModSounds.DEVOURER_VOID_RAY.get(), 4.0f, 0.6f);

        Vec3 start = boss.position().add(0, 2.5, 0);
        Vec3 dir = target.position().add(0, target.getEyeHeight()/2.0, 0)
                        .subtract(start).normalize();

        if (boss.level() instanceof ServerLevel sl) {
            boolean hit = false;
            for (double d = 0; d < 32 && !hit; d += 0.5) {
                Vec3 pt = start.add(dir.scale(d));
                sl.sendParticles(ModParticles.VOID_CRYSTAL.get(),
                    pt.x, pt.y, pt.z, 1, 0, 0, 0, 0.01);
                for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class,
                    new AABB(pt.x-0.5, pt.y-0.5, pt.z-0.5, pt.x+0.5, pt.y+0.5, pt.z+0.5))) {
                    if (e != boss) {
                        e.hurt(boss.damageSources().magic(), boss.getPhase() == 3 ? 20f : 14f);
                        hit = true;
                        break;
                    }
                }
            }
        }
        boss.setCooldown(COOLDOWN);
    }

    @Override
    public void stop() {
        tick = 0;
        boss.setCharging(false);
    }
}
