package com.devourervoid.entity;

import com.devourervoid.init.ModEntities;
import com.devourervoid.init.ModParticles;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.*;
import software.bernie.geckolib.util.GeckoLibUtil;

public class VoidCrystalEntity extends PathfinderMob implements GeoEntity {

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private LivingEntity chaseTarget;
    private int lifetime = 200;

    // construtor usado pelo Goal ao spawnar
    public VoidCrystalEntity(Level level, double x, double y, double z, LivingEntity target) {
        super(ModEntities.VOID_CRYSTAL.get(), level);
        setPos(x, y, z);
        this.chaseTarget = target;
        this.setNoGravity(true);
    }

    // construtor exigido pelo EntityType
    public VoidCrystalEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setNoGravity(true);
    }

    @Override
    protected void registerGoals() { /* movimento manual */ }

    @Override
    public void tick() {
        super.tick();
        lifetime--;

        if (chaseTarget != null && chaseTarget.isAlive()) {
            Vec3 dir = chaseTarget.position().subtract(position()).normalize();
            setDeltaMovement(dir.scale(0.35));
        }

        if (level().isClientSide && tickCount % 2 == 0) {
            level().addParticle(ModParticles.VOID_CRYSTAL.get(),
                getX(), getY() + 0.5, getZ(), 0, -0.02, 0);
        }

        if (!level().isClientSide) {
            if (chaseTarget != null && distanceToSqr(chaseTarget) < 1.5) {
                chaseTarget.hurt(damageSources().magic(), 8.0f);
                explode();
            }
            if (lifetime <= 0) explode();
        }
    }

    private void explode() {
        if (!level().isClientSide) discard();
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar r) {
        r.add(new AnimationController<>(this, "float", 0,
            state -> state.setAndContinue(
                RawAnimation.begin().thenLoop("animation.void_crystal.float"))));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
