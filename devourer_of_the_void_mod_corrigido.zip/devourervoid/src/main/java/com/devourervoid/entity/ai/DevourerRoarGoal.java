package com.devourervoid.entity.ai;

import com.devourervoid.entity.DevourerEntity;
import com.devourervoid.init.ModSounds;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.AABB;

import java.util.EnumSet;
import java.util.List;

public class DevourerRoarGoal extends Goal {

    private final DevourerEntity boss;
    private int tick = 0;
    private static final int COOLDOWN = 180;

    public DevourerRoarGoal(DevourerEntity boss) {
        this.boss = boss;
        setFlags(EnumSet.of(Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        return boss.canAttack() && boss.getTarget() != null
            && boss.distanceToSqr(boss.getTarget()) < 100.0
            && boss.getRandom().nextInt(15) == 0;
    }

    @Override
    public void start() {
        tick = 0;
        boss.setRoaring(true);
        boss.playSound(ModSounds.DEVOURER_ROAR.get(), 5.0f, 0.6f);
        AABB area = boss.getBoundingBox().inflate(10.0, 5.0, 10.0);
        List<LivingEntity> nearby = boss.level().getEntitiesOfClass(LivingEntity.class, area);
        for (LivingEntity e : nearby) {
            if (e == boss) continue;
            double dx = e.getX() - boss.getX();
            double dz = e.getZ() - boss.getZ();
            double len = Math.sqrt(dx*dx + dz*dz);
            if (len > 0) {
                e.setDeltaMovement(e.getDeltaMovement().add(dx/len*1.8, 0.4, dz/len*1.8));
            }
        }
        boss.setCooldown(COOLDOWN);
    }

    @Override
    public boolean canContinueToUse() { return tick < 40; }

    @Override
    public void tick() { tick++; }

    @Override
    public void stop() {
        tick = 0;
        boss.setRoaring(false);
    }
}
