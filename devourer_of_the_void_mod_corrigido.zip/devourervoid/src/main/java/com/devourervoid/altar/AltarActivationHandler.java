package com.devourervoid.altar;

import com.devourervoid.init.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;

@Mod.EventBusSubscriber(modid = com.devourervoid.DevourerMod.MOD_ID)
public class AltarActivationHandler {

    private static final Map<BlockPos, Long> cooldowns = new HashMap<>();

    // Estrutura do altar:
    //   Centro (y=0): sculk_shrieker
    //   4 cantos (±3, 0, ±3): sculk_sensor
    //   Centro (y=1): end_stone (funciona como cristal cósmico placeholder)
    @SubscribeEvent
    public static void onRightClick(PlayerInteractEvent.RightClickBlock event) {
        Level level = event.getLevel();
        BlockPos pos = event.getPos().immutable();
        if (event.getHand() != InteractionHand.MAIN_HAND) return;
        if (!level.getBlockState(pos).is(Blocks.SCULK_SHRIEKER)) return;
        if (level.isClientSide) return;

        long now = level.getGameTime();
        if (cooldowns.getOrDefault(pos, 0L) > now) return;
        cooldowns.put(pos, now + 200L);

        if (!isValidAltar(level, pos)) {
            event.getEntity().sendSystemMessage(
                Component.literal("§5[Altar] §7Estrutura incompleta."));
            return;
        }

        level.playSound(null, pos.getX(), pos.getY(), pos.getZ(),
            ModSounds.DEVOURER_PHASE_SHIFT.get(),
            net.minecraft.sounds.SoundSource.HOSTILE, 3.0f, 0.5f);

        event.getEntity().sendSystemMessage(
            Component.literal("§5[Altar] §bO ritual começa... O Devorador desperta."));

        RitualTickHandler.scheduleRitual(level, pos, now + 100L);
        event.setCanceled(true);
    }

    private static boolean isValidAltar(Level level, BlockPos center) {
        int[][] corners = {{3,0,3},{-3,0,3},{3,0,-3},{-3,0,-3}};
        for (int[] c : corners) {
            if (!level.getBlockState(center.offset(c[0],c[1],c[2])).is(Blocks.SCULK_SENSOR))
                return false;
        }
        return level.getBlockState(center.above()).is(Blocks.END_STONE);
    }
}
