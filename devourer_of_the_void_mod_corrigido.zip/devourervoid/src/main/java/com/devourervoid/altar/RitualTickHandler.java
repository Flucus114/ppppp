package com.devourervoid.altar;

import com.devourervoid.DevourerMod;
import com.devourervoid.entity.DevourerEntity;
import com.devourervoid.init.ModEntities;
import com.devourervoid.init.ModParticles;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Mod.EventBusSubscriber(modid = DevourerMod.MOD_ID)
public class RitualTickHandler {

    private record Ritual(ResourceKey<Level> dimension, BlockPos center, long spawnAt) {}

    private static final List<Ritual> pending = new ArrayList<>();

    public static void scheduleRitual(Level level, BlockPos center, long spawnAt) {
        pending.add(new Ritual(level.dimension(), center.immutable(), spawnAt));
    }

    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.level instanceof ServerLevel sl)) return;

        long now = sl.getGameTime();
        Iterator<Ritual> it = pending.iterator();
        while (it.hasNext()) {
            Ritual r = it.next();
            if (!r.dimension().equals(sl.dimension())) continue; // so processa na dimensao certa

            BlockPos center = r.center();
            if (r.spawnAt() > now) {
                if (now % 4 == 0) {
                    for (int i = 0; i < 8; i++) {
                        sl.sendParticles(ModParticles.COSMIC_ENERGY.get(),
                            center.getX() + (sl.getRandom().nextDouble() - 0.5) * 8,
                            center.getY() + 1.0,
                            center.getZ() + (sl.getRandom().nextDouble() - 0.5) * 8,
                            1, 0, 0.05, 0, 0.02);
                    }
                }
                continue;
            }

            DevourerEntity boss = ModEntities.DEVOURER.get().create(sl);
            if (boss != null) {
                boss.moveTo(center.getX() + 0.5, center.getY() + 1.0, center.getZ() + 0.5,
                    sl.getRandom().nextFloat() * 360f, 0f);
                sl.addFreshEntity(boss);
                for (int i = 0; i < 80; i++) {
                    sl.sendParticles(ModParticles.COSMIC_ENERGY.get(),
                        center.getX() + (sl.getRandom().nextDouble() - 0.5) * 5,
                        center.getY() + sl.getRandom().nextDouble() * 6,
                        center.getZ() + (sl.getRandom().nextDouble() - 0.5) * 5,
                        1, 0, 0.2, 0, 0.1);
                }
            }
            it.remove();
        }
    }
}
