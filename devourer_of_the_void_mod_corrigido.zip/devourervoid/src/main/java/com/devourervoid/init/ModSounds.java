package com.devourervoid.init;

import com.devourervoid.DevourerMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {

    public static final DeferredRegister<SoundEvent> SOUNDS =
        DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, DevourerMod.MOD_ID);

    private static RegistryObject<SoundEvent> reg(String name) {
        ResourceLocation loc = new ResourceLocation(DevourerMod.MOD_ID, name);
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(loc));
    }

    public static final RegistryObject<SoundEvent> DEVOURER_AMBIENT       = reg("entity.devourer.ambient");
    public static final RegistryObject<SoundEvent> DEVOURER_ROAR          = reg("entity.devourer.roar");
    public static final RegistryObject<SoundEvent> DEVOURER_STEP          = reg("entity.devourer.step");
    public static final RegistryObject<SoundEvent> DEVOURER_SMASH         = reg("entity.devourer.smash");
    public static final RegistryObject<SoundEvent> DEVOURER_CORE_CHARGE   = reg("entity.devourer.core_charge");
    public static final RegistryObject<SoundEvent> DEVOURER_VOID_RAY      = reg("entity.devourer.void_ray");
    public static final RegistryObject<SoundEvent> DEVOURER_CRYSTAL_SUMMON= reg("entity.devourer.crystal_summon");
    public static final RegistryObject<SoundEvent> DEVOURER_PHASE_SHIFT   = reg("entity.devourer.phase_shift");
    public static final RegistryObject<SoundEvent> DEVOURER_DEATH         = reg("entity.devourer.death");
    public static final RegistryObject<SoundEvent> DEVOURER_COLLAPSE      = reg("entity.devourer.collapse");
}
