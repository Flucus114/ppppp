package com.devourervoid.init;

import com.devourervoid.DevourerMod;
import net.minecraft.core.particles.ParticleType;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModParticles {

    public static final DeferredRegister<ParticleType<?>> PARTICLES =
        DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, DevourerMod.MOD_ID);

    public static final RegistryObject<SimpleParticleType> SCULK_SHARD =
        PARTICLES.register("sculk_shard", () -> new SimpleParticleType(false));

    public static final RegistryObject<SimpleParticleType> COSMIC_ENERGY =
        PARTICLES.register("cosmic_energy", () -> new SimpleParticleType(false));

    public static final RegistryObject<SimpleParticleType> VOID_CRYSTAL =
        PARTICLES.register("void_crystal", () -> new SimpleParticleType(false));
}
